#!/bin/bash
for LOOP in {01..50};
do
  mkdir /lab/student$LOOP -p
  cat /root/pv.yml  |sed "s/student/student$LOOP/g" | oc create -f -  
done
